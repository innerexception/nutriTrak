
//TODO fix positioning/sizing of meal bars to day bar

//TODO MealBuilder rules: -----------
//TODO add water tracking to meal builder
//TODO add free (recharge meal) checkbox to meal builder, (gray out when appropriate)
//TODO Protein is required
//TODO Protein requires min 1 carb or veg
//TODO add extra advice text with an info button hover
//TODO penalty for eating 1st meal too late
//TODO show bonuses/penalties during meal builder
//TODO ------------------
